const exp = require('express');
const router = exp.Router();
const multer = require('multer');
const DIR = './uploads/';

let upload = multer({ dest: DIR }).single('file');

router.post('/upload', (req, res, next) => {
    let path = '';
    upload(req, res, (err) => {
        if (err) {
            console.log(err);
            return res.status(422).send('An error occured');
        }
        path = req.file.path;
        console.log('Uploaded');
        return res.send('Upload completed for ' + path);
    });
});
module.exports = router;
