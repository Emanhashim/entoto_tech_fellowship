# Run the application
Do npm install to install the necessary dependencies, and then run the below commands in two terminal windows:
* npm run server
* ng serve